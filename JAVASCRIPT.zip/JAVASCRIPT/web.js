//create function for heading time*/

function newTime() {
    var webTime = new Date();
    document.getElementById('headTime').innerHTML = webTime.toLocaleTimeString();
  }
  document.addEventListener('DOMContentLoaded', newTime);
  setInterval(newTime, 100);
  
  //read more about me
  
  function readMore() {
    var rd = document.getElementById('readmore');
    if (rd.style.display === 'none') {
        rd.style.display = 'block';
    } else {
        rd.style.display = 'none';
    }
  }
  
  readMore();
  
  //validate contact
  
  function validateContact() {
    var text = document.contact.firstname.value;
    if (text ==="") {
        alert("Please type your firstname");
    }
    var text2 = document.contact.lastname.value;
    if (text2 === "") {
        alert("Please type your lastname");
    }
    var text3 = document.contact.country.value;
    if (text3 === "") {
        alert("Please type your country");
    }
    var text4 = document.contact.mail.value;
    if (text4 === "") {
        alert("Please type your email address");
    }
    var text5 = document.contact.comment.value;
    if (text5 === "") {
        alert("Please give your comment");
    }
  
  }
  validateContact();
  
  //hide complete cv//
  
  function hidCv() {
    var hide = document.getElementById('hideCv');
    if (hide.style.display === 'none') {
        hide.style.display = 'block';
    } else {
        hide.style.display = 'none';
    }
  }
  hidCv();
  
  